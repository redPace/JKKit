//
//  Tool1.h
//  JKKit
//
//  Created by liqinghong123 on 2017/10/18.
//  Copyright © 2017年 liqinghong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool1 : NSObject

- (void)printName:(NSString *)name;

@end
