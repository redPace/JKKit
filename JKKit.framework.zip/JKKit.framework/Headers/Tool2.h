//
//  Tool2.h
//  JKKit
//
//  Created by liqinghong123 on 2017/10/18.
//  Copyright © 2017年 liqinghong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool2 : NSObject

- (void)printMyName;

@end
