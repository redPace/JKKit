//
//  JKKit.h
//  JKKit
//
//  Created by liqinghong123 on 2017/10/18.
//  Copyright © 2017年 liqinghong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tool1.h"
#import "Tool2.h"

//! Project version number for JKKit.
FOUNDATION_EXPORT double JKKitVersionNumber;

//! Project version string for JKKit.
FOUNDATION_EXPORT const unsigned char JKKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JKKit/PublicHeader.h>


